<?php

use yii\bootstrap\ActiveForm;
use yii\helpers\Html;

$this->title = 'Create Pegawai';
$this->params['breadcrumbs'][] = ['label' => 'Administrasi Pegawai', 'url' => ['/administrasipegawai/default']];
$this->params['breadcrumbs'][] = ['label' => 'Daftar Pegawai', 'url' => ['default/index']];
$this->params['breadcrumbs'][] = $this->title;
?>

<?= Html::a('Kembali', ['default/index'], ['class' => 'btn btn-warning pull-right']) ?>

<div class="tmst-pegawai-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?php
    $form = ActiveForm::begin([
                'layout' => 'horizontal',
                'class' => 'form-horizontal',
                'options' => ['enctype' => 'multipart/form-data'],
    ]);
    ?>

    <?=
    $this->render('_form', [
        'model' => $model,
        'form' => $form,
    ])
    ?>

    <?php ActiveForm::end(); ?>

</div>
