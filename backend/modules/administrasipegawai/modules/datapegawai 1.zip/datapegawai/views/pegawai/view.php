<?php
$this->title = 'Detail Pegawai';
$this->params['breadcrumbs'][] = ['label' => 'Administrasi Pegawai', 'url' => ['/administrasipegawai/default']];
$this->params['breadcrumbs'][] = ['label' => 'Daftar Pegawai', 'url' => ['default/index']];
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="tmst-pegawai-view">
    <?php
//    echo $this->render('/backend/', ['model' => $model,]);
//    echo $this->renderPartial('//default/_header', ['model' => $model,]);
    ?>
    <?= $this->render('@backend/modules/administrasipegawai/modules/datapegawai/views/default/_header', ['model' => $model,]) ?>

    <div class="body-content">
        <?php echo $this->render($page, ['model' => $model, 'id' => $id,]); ?>
    </div>

</div>