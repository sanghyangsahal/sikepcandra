<?php

use yii\helpers\Html;

$this->title = 'Update Pegawai';
$this->params['breadcrumbs'][] = 'Update';
?>

<div class="tmst-pegawai-update">

    <h1><?= Html::encode($this->title) ?></h1>

    <?= $this->render('_form', ['model' => $model,]) ?>

</div>
